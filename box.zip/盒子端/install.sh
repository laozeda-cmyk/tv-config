#!/data/data/com.termux/files/usr/bin/sh
# 一键安装脚本：自动装 node、复制文件、后台启动代理
# 用法（在 Termux 里）: sh /sdcard/Download/盒子端/install.sh

echo "[1/4] 检查存储权限 ..."
termux-setup-storage 2>/dev/null || true

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[2/4] 检查 nodejs ..."
if ! command -v node >/dev/null 2>&1; then
  echo "正在安装 nodejs，首次安装约 1-2 分钟 ..."
  pkg install -y nodejs
fi

echo "[3/4] 复制程序到家目录 ..."
mkdir -p "$HOME/mytv"
cp -f "$SRC_DIR"/mytv_proxy.mjs "$SRC_DIR"/mytv_resolver_child.mjs "$SRC_DIR"/start.sh "$SRC_DIR"/stop.sh "$HOME/mytv/" 2>/dev/null || true
cp -rf "$SRC_DIR"/extracted "$HOME/mytv/" 2>/dev/null || true

echo "[4/4] 后台启动代理 ..."
cd "$HOME/mytv" || exit 1
sh start.sh

echo ""
echo "全部完成！接下来只需两步："
echo "1. 影视仓配置里把 192.168.31.140 全部改成 127.0.0.1"
echo "2. 重新加载直播配置即可观看"
echo ""
echo "开机自启（可选，推荐）："
echo "  mkdir -p ~/.termux/boot && cp ~/mytv/start.sh ~/.termux/boot/start_mytv_proxy.sh"
