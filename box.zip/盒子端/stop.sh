#!/data/data/com.termux/files/usr/bin/sh
# 停止影视仓直播代理
pkill -f "mytv_proxy.mjs" && echo "代理已停止" || echo "没有在运行的代理"
