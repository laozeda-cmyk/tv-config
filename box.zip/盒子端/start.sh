#!/data/data/com.termux/files/usr/bin/sh
# 影视仓直播代理 - 盒子后台启动脚本
# 用法: sh start.sh [端口]   （默认端口 8787）
cd "$(dirname "$0")" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo "[错误] 未找到 node，请先在 Termux 执行: pkg install -y nodejs"
  exit 1
fi

PORT="${1:-8787}"

port_in_use() {
  if command -v ss >/dev/null 2>&1; then
    ss -ltn 2>/dev/null | grep -q ":$PORT " && return 0
  fi
  if command -v netstat >/dev/null 2>&1; then
    netstat -ltn 2>/dev/null | grep -q ":$PORT " && return 0
  fi
  return 1
}

if port_in_use; then
  echo "端口 $PORT 已被占用，代理可能已在运行，无需重复启动"
  exit 0
fi

nohup node mytv_proxy.mjs "$PORT" >> mytv.log 2>&1 &
echo "代理已后台启动: 端口 $PORT, PID $!"
echo "日志文件: $(pwd)/mytv.log"
echo "影视仓配置地址请改为: http://127.0.0.1:$PORT/live/..."
