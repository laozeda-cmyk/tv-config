// 子进程解析器：独立运行 MyTV 播放器 JS，结果以 RESULT json 输出
import crypto from "crypto";
import fs from "fs";
import path from "path";
import vm from "vm";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WD = path.join(__dirname, "extracted", "wd");
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36";

let inputRaw = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (d) => (inputRaw += d));
process.stdin.on("end", () => {
  main(inputRaw);
});

function main(raw) {
  let input;
  try {
    input = JSON.parse(raw || "{}");
  } catch (e) {
    fail("bad input: " + e.message);
    return;
  }
  run(input);
}

function run(input) {
const player = input.player || "";
const args = input.args || {};

function load(name) {
  const p = path.join(WD, name);
  return fs.existsSync(p) ? fs.readFileSync(p, "utf8") : null;
}

function fillTemplate(code, a) {
  return code
    .replace(/\{\{liveUrl\}\}/g, a.liveUrl || "")
    .replace(/\{\{id\}\}/g, a.id || "")
    .replace(/\{\{pid\}\}/g, a.pid || "")
    .replace(/\{\{streamId\}\}/g, a.streamId || "")
    .replace(/\{\{channelName\}\}/g, a.channelName || "")
    .replace(/\{\{code\}\}/g, a.code || "");
}

function fail(msg) {
  console.log("ERROR " + String(msg || "unknown").slice(0, 300));
  process.exit(1);
}

process.on("uncaughtException", (e) => fail(e && e.message));
process.on("unhandledRejection", (e) => fail((e && e.message) || "rejection"));

let done = false;
function finish(obj) {
  if (done) return;
  done = true;
  console.log("RESULT " + JSON.stringify(obj));
  process.exit(0);
}

const realSetTimeout = setTimeout;
const docShim = {
  createElement: () => {
    const el = { src: "", _onload: null, setAttribute() {}, appendChild() {} };
    Object.defineProperty(el, "onload", {
      get() { return el._onload; },
      set(fn) {
        el._onload = fn;
        if (typeof fn === "function") realSetTimeout(() => { try { fn(); } catch (e) { fail(e.message); } }, 0);
      },
    });
    return el;
  },
  head: {
    appendChild(el) {
      if (el && typeof el.onload === "function") realSetTimeout(() => { try { el.onload(); } catch (e) { fail(e.message); } }, 0);
    },
  },
  body: { appendChild() {} },
  querySelector: () => null,
  querySelectorAll: () => [],
  getElementById: () => null,
  addEventListener() {},
  documentElement: {},
};

const sandbox = {
  console: { log: () => {}, error: () => {} },
  setTimeout: (fn, ms, ...a) => realSetTimeout(() => { try { fn(...a); } catch (e) { fail(e.message); } }, ms),
  clearTimeout,
  setInterval: () => 0,
  clearInterval: () => {},
  Math, Date, JSON, Object, Array, String, Number, Boolean, RegExp, Promise,
  URL, URLSearchParams, Map, Set, Symbol, BigInt,
  Blob, Headers, Request, Response, AbortController,
  TextEncoder, TextDecoder,
  encodeURIComponent, decodeURIComponent,
  btoa: (s) => Buffer.from(s, "binary").toString("base64"),
  atob: (s) => Buffer.from(s, "base64").toString("binary"),
  fetch,
  navigator: { userAgent: UA, language: "zh-CN", platform: "Win32" },
  location: {
    href: "",
    assign(u) { finish({ type: "redirect", url: String(u) }); },
    replace(u) { finish({ type: "redirect", url: String(u) }); },
  },
  document: docShim,
  JSBridge: {
    hideLoading() {},
    showLoading() {},
    toast() {},
    async httpRequest(url, method, headersJson, body) {
      try {
        const headers = JSON.parse(headersJson || "{}");
        const res = await fetch(url, {
          method: String(method || "GET"),
          headers,
          body: body || undefined,
        });
        const text = await res.text();
        const hdrs = {};
        res.headers.forEach((v, k) => (hdrs[k] = [v]));
        return JSON.stringify({
          status: res.status,
          statusText: res.statusText,
          headers: hdrs,
          body: text,
        });
      } catch (e) {
        return JSON.stringify({ error: true, message: String(e.message || e) });
      }
    },
  },
  crypto: {
    getRandomValues(arr) {
      for (let i = 0; i < arr.length; i++) arr[i] = Math.floor(Math.random() * 256);
      return arr;
    },
    randomUUID: () => crypto.randomUUID(),
  },
  playLive(url, headers) { finish({ type: "play", url: String(url), headers: headers || {} }); },
  startPlay(id) { finish({ type: "start", id: String(id) }); },
  window: null,
};
sandbox.window = sandbox;

for (const lib of ["dy-crypto-js.min", "jsencrypt", "dy-http-util"]) {
  const code = load(`js__lib__${lib}.js`);
  if (code) {
    try { vm.runInNewContext(code, sandbox, { timeout: 5000 }); } catch (e) { fail("lib " + lib + ": " + e.message); }
  }
}

const scriptCode = load(`js__${player}__init.js`) || load(`js__${player}__play.js`);
if (!scriptCode) fail("no script for " + player);

try {
  vm.runInNewContext(fillTemplate(scriptCode, args), sandbox, { timeout: 10000 });
} catch (e) {
  fail("exec: " + e.message);
}

realSetTimeout(() => fail("timeout"), 12000);
}
