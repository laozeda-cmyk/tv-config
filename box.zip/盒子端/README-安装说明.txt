影视仓直播代理 - 盒子端快速安装
================================

作用：让盒子代替电脑跑直播代理，电脑可以关机。

只要 3 步：

第 1 步：盒子装 Termux
  下载：https://github.com/termux/termux-app/releases
  选 termux-app_v0.118.x+android-7+apk 那个安装包，U 盘安装。

第 2 步：把"盒子端"整个文件夹拷到盒子的
  /sdcard/Download/ 目录下（U 盘拷贝即可）

第 3 步：打开 Termux，敲两行命令：

  termux-setup-storage
  （弹出权限框时选"允许"）

  sh /sdcard/Download/盒子端/install.sh

  脚本会自动装 nodejs、复制文件、后台启动，看到"全部完成"就行。
  然后影视仓配置里把 192.168.31.140 改成 127.0.0.1，重新加载即可。

开机自启（推荐）：
  mkdir -p ~/.termux/boot && cp ~/mytv/start.sh ~/.termux/boot/start_mytv_proxy.sh
  （需要另装 Termux:Boot：https://github.com/termux/termux-boot/releases）

常用命令：
  启动  sh ~/mytv/start.sh    停止  sh ~/mytv/stop.sh
  看日志  tail -f ~/mytv/mytv.log

注意：
  - 盒子设置里给 Termux 开"允许后台运行"，防止休眠被杀。
  - 个别台播不了是源本身的问题，和电脑上结果一样，不是装坏了。
  - 如果不想折腾盒子，电脑上代理现在就在跑（192.168.31.140:8787），
    什么都不用装，直接看。
