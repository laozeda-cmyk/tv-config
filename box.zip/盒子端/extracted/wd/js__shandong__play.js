(function() {
    getShanDongLiveUrl('{{channelId}}')
})();