// 我的电视 → 影视仓 专用播放器代理
// 用法: node apk/mytv_proxy.mjs [端口]
// 影视仓地址示例: http://127.0.0.1:8787/live/jiangsu?liveUrl=https%3A%2F%2Flitchi-play-encrypted-site.jstv.com%2Fapplive%2Fjswspro.m3u8
import crypto from "crypto";
import { spawn } from "child_process";
import fs from "fs";
import http from "http";
import os from "os";
import path from "path";
import vm from "vm";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WD = path.join(__dirname, "extracted", "wd");
const PORT = Number(process.argv[2] || process.env.PORT || 8787);
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36";

function scriptPath(player, kind) {
  const p = path.join(WD, `js__${player}__${kind}.js`);
  return fs.existsSync(p) ? p : null;
}

function loadScript(player, kind) {
  const p = scriptPath(player, kind);
  return p ? fs.readFileSync(p, "utf8") : null;
}

function loadLib(name) {
  const p = path.join(WD, `js__lib__${name}.js`);
  return fs.existsSync(p) ? fs.readFileSync(p, "utf8") : null;
}

function fillTemplate(code, args) {
  return code
    .replace(/\{\{liveUrl\}\}/g, args.liveUrl || "")
    .replace(/\{\{id\}\}/g, args.id || "")
    .replace(/\{\{pid\}\}/g, args.pid || "")
    .replace(/\{\{streamId\}\}/g, args.streamId || "")
    .replace(/\{\{channelName\}\}/g, args.channelName || "");
}

function makeSandbox(capture) {
  const docShim = {
    createElement: () => {
      const el = { src: "", _onload: null, setAttribute() {}, appendChild() {} };
      Object.defineProperty(el, "onload", {
        get() { return el._onload; },
        set(fn) { el._onload = fn; if (typeof fn === "function") setTimeout(fn, 0); },
      });
      return el;
    },
    head: { appendChild(el) { if (el && typeof el.onload === "function") setTimeout(el.onload, 0); } },
    body: { appendChild() {} },
    querySelector: () => null,
    querySelectorAll: () => [],
    getElementById: () => null,
    addEventListener() {},
    documentElement: {},
  };
  const sandbox = {
    console: { log: (...a) => console.log("[wd]", ...a), error: (...a) => console.error("[wd]", ...a) },
    setTimeout,
    clearTimeout,
    setInterval: () => 0,
    clearInterval: () => {},
    Math, Date, JSON, Object, Array, String, Number, Boolean, RegExp, Promise,
    encodeURIComponent, decodeURIComponent,
    btoa: (s) => Buffer.from(s, "binary").toString("base64"),
    atob: (s) => Buffer.from(s, "base64").toString("binary"),
    fetch,
    navigator: { userAgent: UA, language: "zh-CN", platform: "Win32" },
    location: {
      href: "",
      assign(u) { capture({ type: "redirect", url: u }); },
      replace(u) { capture({ type: "redirect", url: u }); },
    },
    document: docShim,
    JSBridge: { hideLoading() {}, showLoading() {}, toast() {} },
    playLive(url, headers) { capture({ type: "play", url: String(url), headers: headers || {} }); },
    startPlay(id) { capture({ type: "start", id: String(id) }); },
    window: null,
  };
  sandbox.window = sandbox;
  docShim.documentElement = docShim;
  const cryptoJs = loadLib("dy-crypto-js.min");
  const jsencrypt = loadLib("jsencrypt");
  if (cryptoJs) {
    try { vm.runInNewContext(cryptoJs, sandbox, { timeout: 5000 }); } catch (e) { console.error("cryptoJs load fail", e.message); }
  }
  if (jsencrypt) {
    try { vm.runInNewContext(jsencrypt, sandbox, { timeout: 5000 }); } catch (e) { console.error("jsencrypt load fail", e.message); }
  }
  return sandbox;
}

function runPlayer(player, args, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    const child = path.join(__dirname, "mytv_resolver_child.mjs");
    const proc = spawn(process.execPath, [child], { windowsHide: true });
    let out = "";
    proc.stdout.on("data", (d) => (out += d));
    proc.stderr.on("data", (d) => (out += d));
    const timer = setTimeout(() => {
      try { proc.kill(); } catch {}
      reject(new Error("player timeout: " + player));
    }, timeoutMs + 5000);
    proc.on("error", (e) => {
      clearTimeout(timer);
      reject(new Error("spawn fail: " + e.message));
    });
    proc.on("close", (code) => {
      clearTimeout(timer);
      const line = out.split("\n").find((l) => l.startsWith("RESULT "));
      if (line) {
        try {
          resolve(JSON.parse(line.slice(7)));
          return;
        } catch {}
      }
      const errLine = out.split("\n").find((l) => l.startsWith("ERROR "));
      reject(new Error("player fail: " + player + " " + (errLine ? errLine.slice(6) : "exit " + code)));
    });
    proc.stdin.end(JSON.stringify({ player, args }));
  });
}

// 江西: cdnauth 换取 token
async function resolveJiangxi(args) {
  const stream = args.id || "tv_jxtv1";
  const t = Math.floor(Date.now() / 1000);
  const uuid = crypto.randomUUID();
  const r = await fetch("https://cdnauth.jxgdw.com/liveauth/pc", {
    method: "POST",
    headers: { "content-type": "application/json", "user-agent": UA, referer: "https://www.jxntv.cn/" },
    body: JSON.stringify({ t, stream, uuid }),
  });
  const j = await r.json();
  return {
    url: `https://yun-live.jxtvcn.com.cn/live-jxtv/${stream}?source=pc&t=${j.t}&token=${j.token}&uuid=${uuid}`,
    headers: { "user-agent": UA, referer: "https://www.jxntv.cn/" },
  };
}

// 湖北: 从官网页面抓 auth_key
let hubeiCache = null;
async function resolveHubei(args) {
  if (!hubeiCache) {
    const r = await fetch("https://news.hbtv.com.cn/app/tv/431", { headers: { "user-agent": UA } });
    const text = await r.text();
    const re = /https:\/\/live21-cjy\.hbtv\.com\.cn\/new-hbtv\/new-([a-z0-9]+)\.m3u8\?auth_key=[^"'\s]+/g;
    const map = {};
    let m;
    while ((m = re.exec(text))) map[m[1]] = m[0];
    hubeiCache = map;
  }
  const idMap = {
    431: "hbws", 432: "hbjs", 433: "hbzh", 434: "hbgg",
    435: "hbys", 436: "hbsh", 437: "hbjy", 438: "hbls",
  };
  const name = args.name || idMap[args.id] || "hbws";
  const url = hubeiCache[name];
  if (!url) throw new Error("hubei channel not found: " + name);
  return { url, headers: { "user-agent": UA, referer: "https://news.hbtv.com.cn/" } };
}

async function resolve(player, args) {
  if (player === "common") {
    return { url: args.liveUrl, headers: {} };
  }
  if (player === "jiangxi") {
    return resolveJiangxi(args);
  }
  if (player === "hubei") {
    return resolveHubei(args);
  }
  const cap = await runPlayer(player, args);
  if (cap.type === "play") {
    if (player === "neimenggu") {
      return {
        url: cap.url,
        headers: { "referer": "https://www.nmtv.cn/", "user-agent": UA },
      };
    }
    return { url: cap.url, headers: cap.headers || {} };
  }
  if (cap.type === "redirect") {
    throw new Error("player redirected to page: " + cap.url);
  }
  if (cap.type === "start") {
    throw new Error("player needs play script for id " + cap.id);
  }
  throw new Error("no play url captured");
}

function b64url(s) {
  return Buffer.from(s, "utf8").toString("base64url");
}
function unb64url(s) {
  return Buffer.from(s, "base64url").toString("utf8");
}

async function fetchGet(url, headers) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 25000);
  try {
    const res = await fetch(url, { headers, redirect: "follow", signal: ctrl.signal });
    const ct = res.headers.get("content-type") || "";
    if (res.status !== 200) throw new Error("upstream " + res.status);
    const buf = Buffer.from(await res.arrayBuffer());
    return { buf, ct };
  } finally {
    clearTimeout(timer);
  }
}

async function fetchUpstream(url, headers, isSegment = false) {
  const h = { "user-agent": UA, ...headers };
  if (h["X-Referer"] && !h["Referer"]) h["Referer"] = h["X-Referer"];
  const { buf, ct } = await fetchGet(url, h);
  if (isSegment) return { buf, ct };
  const text = buf.toString("utf8");
  const isM3u8 = text.includes("#EXTM3U") || text.includes("#EXTINF");
  if (!isM3u8) return { buf, ct };
  const hdr = b64url(JSON.stringify(headers));
  const rewritten = text
    .split("\n")
    .map((line) => {
      const l = line.trim();
      if (!l || l.startsWith("#")) return line;
      let abs;
      try {
        abs = new URL(l, url).toString();
      } catch {
        return line;
      }
      return `/seg?h=${hdr}&u=${b64url(abs)}`;
    })
    .join("\n");
  return { buf: Buffer.from(rewritten, "utf8"), ct: "application/vnd.apple.mpegurl" };
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, "http://x");
  try {
    if (u.pathname === "/seg") {
      const headers = JSON.parse(unb64url(u.searchParams.get("h") || "e30="));
      const target = unb64url(u.searchParams.get("u") || "");
      const { buf, ct } = await fetchUpstream(target, headers, true);
      res.writeHead(200, { "content-type": ct || "video/mp2t", "cache-control": "no-store" });
      res.end(buf);
      return;
    }
    if (u.pathname === "/resolve") {
      const player = u.searchParams.get("player") || "";
      const args = Object.fromEntries(u.searchParams);
      const r = await resolve(player, args);
      res.writeHead(200, { "content-type": "application/json" });
      res.end(JSON.stringify(r));
      return;
    }
    if (u.pathname.startsWith("/live/")) {
      const player = u.pathname.slice(6);
      const args = Object.fromEntries(u.searchParams);
      const { url, headers } = await resolve(player, args);
      const { buf, ct } = await fetchUpstream(url, headers);
      res.writeHead(200, { "content-type": ct || "application/vnd.apple.mpegurl", "cache-control": "no-store" });
      res.end(buf);
      return;
    }
    res.writeHead(404, { "content-type": "text/plain; charset=utf-8" });
    res.end("not found");
  } catch (e) {
    console.error("ERR", req.url, e.message);
    res.writeHead(502, { "content-type": "text/plain; charset=utf-8" });
    res.end(String(e.message || e));
  }
});

server.listen(PORT, "0.0.0.0", () => {
  console.log("MyTV live proxy listening on http://0.0.0.0:" + PORT);
  console.log("示例: http://127.0.0.1:" + PORT + "/live/jiangsu?liveUrl=https%3A%2F%2Flitchi-play-encrypted-site.jstv.com%2Fapplive%2Fjswspro.m3u8");
});
